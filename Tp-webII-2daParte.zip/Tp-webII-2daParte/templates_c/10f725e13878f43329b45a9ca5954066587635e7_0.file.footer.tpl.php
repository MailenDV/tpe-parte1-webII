<?php
/* Smarty version 4.2.1, created on 2022-10-08 05:16:00
  from 'C:\xampp\htdocs\todo-list-main\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_6340eb70236428_90245239',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '10f725e13878f43329b45a9ca5954066587635e7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\todo-list-main\\templates\\footer.tpl',
      1 => 1665100963,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6340eb70236428_90245239 (Smarty_Internal_Template $_smarty_tpl) {
?></main>
<!-- fin main container -->


<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
