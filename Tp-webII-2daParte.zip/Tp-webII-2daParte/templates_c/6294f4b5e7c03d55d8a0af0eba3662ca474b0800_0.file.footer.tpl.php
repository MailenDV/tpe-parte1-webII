<?php
/* Smarty version 4.2.1, created on 2022-10-18 02:13:13
  from 'C:\xampp\htdocs\Tpe-WebII-Mai\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_634def99f3a901_09145878',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6294f4b5e7c03d55d8a0af0eba3662ca474b0800' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Tpe-WebII-Mai\\templates\\footer.tpl',
      1 => 1665285448,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_634def99f3a901_09145878 (Smarty_Internal_Template $_smarty_tpl) {
?></main>


<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
