<?php
/* Smarty version 4.2.1, created on 2023-10-13 01:44:24
  from 'C:\xampp\htdocs\Tp-webII-2daParte\templates\img_formalta.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_652884d833a405_43852348',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5811a38c7b5fb5dbb5fb6df6c6959e2df1ffdf57' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Tp-webII-2daParte\\templates\\img_formalta.tpl',
      1 => 1697154226,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_652884d833a405_43852348 (Smarty_Internal_Template $_smarty_tpl) {
?><main class="container mt-5">
     <div class="col">
            <div class="center" style="width: 80rem" style="height: 10rem">
                <img class="card-img-top" src="images/10.png">        
            </div>
        </div>
    </main><?php }
}
