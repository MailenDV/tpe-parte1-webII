<?php
/* Smarty version 4.2.1, created on 2022-10-18 01:48:24
  from 'C:\xampp\htdocs\TPE_Web_Mai\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_634de9c82e23c4_20286066',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '66697c5adeae9324185cb8f7a49b9bbcdfbd42b9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\TPE_Web_Mai\\templates\\footer.tpl',
      1 => 1665285448,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_634de9c82e23c4_20286066 (Smarty_Internal_Template $_smarty_tpl) {
?></main>


<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
