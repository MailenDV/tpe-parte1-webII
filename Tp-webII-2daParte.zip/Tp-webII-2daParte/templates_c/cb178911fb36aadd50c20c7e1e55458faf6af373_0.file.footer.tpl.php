<?php
/* Smarty version 4.2.1, created on 2023-10-08 22:14:22
  from 'C:\xampp\htdocs\Tp-webII-2daParte\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_65230d9eb0ea43_08450040',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cb178911fb36aadd50c20c7e1e55458faf6af373' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Tp-webII-2daParte\\templates\\footer.tpl',
      1 => 1696215035,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65230d9eb0ea43_08450040 (Smarty_Internal_Template $_smarty_tpl) {
?></main>
<!-- fin main container -->

<!-- main footer -->
<footer class="d-flex flex-wrap justify-content-center align-items-center py-3 my-4 border-top">
      <div class="align-items-center">
        <span class="text-muted">© 2003-2023 Formula One World Championship Limited </span>
      </div>
</footer>
  
<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"><?php echo '</script'; ?>
>

</body>
</html><?php }
}
