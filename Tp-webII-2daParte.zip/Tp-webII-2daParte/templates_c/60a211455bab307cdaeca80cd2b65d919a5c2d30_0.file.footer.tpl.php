<?php
/* Smarty version 4.2.1, created on 2022-10-09 05:18:50
  from 'C:\xampp\htdocs\Mai\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.2.1',
  'unifunc' => 'content_63423d9a24e4c3_36198724',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '60a211455bab307cdaeca80cd2b65d919a5c2d30' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Mai\\templates\\footer.tpl',
      1 => 1665285448,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63423d9a24e4c3_36198724 (Smarty_Internal_Template $_smarty_tpl) {
?></main>


<?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
